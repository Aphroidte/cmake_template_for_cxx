#include <iostream>
#include <sstream>
#include <string>
#include "binary_tree.h"

int main()
{
    CBinaryTree bt;
    bt.CreateByInput();

    std::stringstream ss;
    bt.PreTraversalRe(ss);
    return 0;
}