#include "gtest/gtest.h"
#include "binary_tree.h"

TEST(BinaryTree, PreTraversa)
{
    CBinaryTree bt;
    bt.m_root = std::make_shared<CTreeNode>('A');
    bt.m_root->m_left = std::make_shared<CTreeNode>('B');
    bt.m_root->m_right = std::make_shared<CTreeNode>('C');

    bt.m_root->m_left->m_left = std::make_shared<CTreeNode>('D');
    bt.m_root->m_right->m_left = std::make_shared<CTreeNode>('E');
    bt.m_root->m_right->m_right = std::make_shared<CTreeNode>('F');

    bt.m_root->m_left->m_left->m_left = std::make_shared<CTreeNode>('G');
    bt.m_root->m_left->m_left->m_right = std::make_shared<CTreeNode>('H');
    bt.m_root->m_right->m_left->m_right = std::make_shared<CTreeNode>('I');

    std::stringstream ss;
    bt.PreTraversalRe(ss);
    std::string ret = ss.str();
    std::cout << "ret: " << ret << std::endl;

    std::stringstream ss2;
    bt.PreTraversa(ss2);
    std::string ret2 = ss2.str();
    std::cout << "ret2: " << ret2 << std::endl;
    EXPECT_EQ(ret, ret2);
}
