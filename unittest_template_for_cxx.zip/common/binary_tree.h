#ifndef _COMMON_BINARY_TREE_H_
#define _COMMON_BINARY_TREE_H_

#include <stdint.h>
#include <iostream>
#include <memory>

/////////////////////////////////////////////////////////////////////
//! 二叉树的实现方式：链表 ////////////////////////////////////////////
//! 树的节点类型
struct CTreeNode
{
public:
    CTreeNode() {}
    CTreeNode(char val)
    {
        m_val = val;
    }

    char GetValue()
    {
        return m_val;
    }

public:
    using SharePtrTreeNode = std::shared_ptr<CTreeNode>;

    char                m_val;      // 本节点的值
    SharePtrTreeNode    m_left;     // 左子树
    SharePtrTreeNode    m_right;    // 右子树
};
using SharePtrTreeNode = std::shared_ptr<CTreeNode>;

//! 二叉树的声明
class CBinaryTree
{
public:
    CBinaryTree() { }

    //! 通过用户输入的方式创建一颗二叉树
    void CreateByInput();

    /**
     * @brief 插入节点
     * @note 普通二叉树的插入，实现起来没有意义
     * @param value 插入节点的内容
     * @return true 表示插入成功
     * @return false 表示插入失败
     */
    bool Insert(int32_t val) { return false; }

    /**
     * @brief 查找值为 val 的节点
     * @param val 需要查找的节点的值
     * @return SharePtrTreeNode 返回找到的节点；nullptr-表示找不到该节点
     */
    //SharePtrTreeNode Find(int32_t val);

    /**
     * @brief 删除值为 val 的节点
     * 
     * @param val 需要删除的节点的值
     */
    //void DelNode(int32_t val);

    //! 前序遍历递归实现
    void PreTraversalRe(std::stringstream &ss);

    //! 前序遍历的非递归实现（使用栈）
    void PreTraversa(std::stringstream &ss);

protected:
    void create(SharePtrTreeNode &node);

    //! 前序遍历的递归实现
    void preorder_traversal_re(SharePtrTreeNode root, std::stringstream &ss);

public:
    SharePtrTreeNode     m_root;     // 树根节点
};

#endif
