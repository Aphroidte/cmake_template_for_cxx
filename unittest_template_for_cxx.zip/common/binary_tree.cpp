#include <iostream>
#include <sstream>
#include <stack>
#include "binary_tree.h"

void CBinaryTree::create(SharePtrTreeNode &node)
{
    char val = 0;
    std::cin >> val;
    if (val == '#')
    {
        node = nullptr;
        return;
    }

    node = std::make_shared<CTreeNode>(CTreeNode(val));

    // 递归创建左子树
    create(node->m_left);
    // 递归创建右子树
    create(node->m_right);
}

//! 通过用户输入的方式创建一颗二叉树
void CBinaryTree::CreateByInput()
{
    create(m_root);
}

//! 前序遍历的递归实现
void CBinaryTree::preorder_traversal_re(SharePtrTreeNode root, std::stringstream &ss)
{
    if (root == nullptr)
    {
        return;
    }
    ss << root->GetValue() << " ";

    // 前序遍历左子树
    preorder_traversal_re(root->m_left, ss);
    preorder_traversal_re(root->m_right, ss);
}

//! 前序遍历递归实现
void CBinaryTree::PreTraversalRe(std::stringstream &ss)
{
    preorder_traversal_re(m_root, ss);
}

//! 前序遍历的非递归实现（使用栈）
void CBinaryTree::PreTraversa(std::stringstream &ss)
{
    std::stack<SharePtrTreeNode> st;
    st.push(m_root);
    while(!st.empty())
    {
        SharePtrTreeNode tmp = st.top();
        st.pop();

        if (tmp == nullptr)
        {
            continue;
        }
        ss << tmp->GetValue() << " ";
        // 插入右子树，左子树遍历完成后，遍历右子树
        st.push(tmp->m_right);
        // 插入左子树，优先遍历左子树
        st.push(tmp->m_left);
        
    }
}
